const axios = require('axios')

module.exports = {
    getData: async (req, res) => {
        try {
            const { category, limit } = req.query
            const response = await axios.get('https://api.publicapis.org/entries')

            let filteredData = response?.data?.entries

            if (!category && !limit) {
                return res.status(200).json({
                    success: true,
                    message: "Successfully fetched data",
                    data: filteredData
                });
            }

            if (category) {
                filteredData = response?.data?.entries.filter(n => n.Category === category);
            }

            if (limit) {
                const limitNum = parseInt(limit);
                if (!isNaN(limitNum)) {
                    filteredData = filteredData.slice(0, limitNum);
                }
            }

            if (response.status === 200) {
                return res.status(200).json({
                    success: true,
                    message: "Successfully fetched data",
                    data: filteredData
                });
            } else {
                return res.status(response.status).json({
                    success: false,
                    message: 'Failed to fetch data from the API'
                });
            }

        } catch (error) {
            console.log("Internal Server Error in getting data")
            return res.status(500).json({
                success: false,
                message: "Internal Server Error"
            })
        }
    }
}


