const express = require('express');
const userRouter = require('../controllers/userRouter');
const verifyToken = require('../middlewares/verifyToken')

const router = express.Router();

router.get('/user', verifyToken, userRouter.getData)

module.exports = router