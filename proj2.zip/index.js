const express = require('express')
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 8000;

app.use(express.json());

app.use("/v1/", require("./routes/router"))

app.listen(PORT, () => {
    console.log(`Server running on PORT ${PORT}`);
});